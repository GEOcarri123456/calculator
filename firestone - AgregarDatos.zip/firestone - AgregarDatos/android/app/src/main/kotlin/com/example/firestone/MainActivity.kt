package com.example.firestone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
